#import the setup funmction from Python's distribution utilities
from distutils.core import setup

setup(
        name = 'looper',
        version ='1.0.0',
        py_modules = ['looper'],
        author = 'Keli',
        author_email = 'muhindi@wazza.co.ke',
        url = 'http://wazza.co.ke',
        description = 'A simple recursive function to loop through list items',
        )
