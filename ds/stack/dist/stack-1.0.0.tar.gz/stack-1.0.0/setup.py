from distutils.core import setup

setup(
        name = 'stack',
        version = '1.0.0',
        py_modules = ['stack'],
        author = 'muhindik',
        author_email = 'kelly@bitforge.co.ke',
        description  = 'This module is an implementation of a queue using list'
        )

